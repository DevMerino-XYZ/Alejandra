import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/user_service.dart';
import '../models/user_model.dart';
import 'login_screen.dart';
import 'admin_home_screen.dart';
import 'user_home_screen.dart';
import 'complete_profile_screen.dart';

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, authSnapshot) {

        // 🔄 Esperando estado de autenticación
        if (authSnapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        // 🚪 No hay sesión iniciada
        if (!authSnapshot.hasData) {
          return const LoginScreen();
        }

        final uid = authSnapshot.data!.uid;

        // 👤 Obtenemos el perfil desde nuestro servicio
        return FutureBuilder<UserModel?>(
          future: UserService().getUser(uid),
          builder: (context, userSnapshot) {

            if (userSnapshot.connectionState == ConnectionState.waiting) {
              return const Scaffold(
                body: Center(child: CircularProgressIndicator()),
              );
            }

            // 📄 Documento no existe → completar perfil
            if (!userSnapshot.hasData || userSnapshot.data == null) {
              return const CompleteProfileScreen();
            }

            final user = userSnapshot.data!;

            // 🔒 Usuario inactivo
            if (!user.isActive) {
              return const Scaffold(
                body: Center(
                  child: Text(
                    'Usuario desactivado.\nContacte al administrador.',
                    textAlign: TextAlign.center,
                  ),
                ),
              );
            }

            // 🧭 Redirección por rol
            if (user.role == 'admin') {
              return const AdminHomeScreen();
            }

            return const UserHomeScreen();
          },
        );
      },
    );
  }
}